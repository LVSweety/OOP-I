package model.item;


public enum Genre {
    ACTION,
    CLASSIC,
    GRAPHIC_NOVEL,
    MYSTERY,
    FANTASY,
    HISTORICAL,
    HORROR
    
    
}
